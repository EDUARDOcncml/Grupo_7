package com.sise.reserva_hotel_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReservaHotelApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
