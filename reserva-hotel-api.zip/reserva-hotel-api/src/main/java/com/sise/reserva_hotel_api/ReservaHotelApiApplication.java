package com.sise.reserva_hotel_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReservaHotelApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReservaHotelApiApplication.class, args);
	}

}
